import React from 'react';

const Contact = () => {
    return (
        <div>
            <h1>My contact page mera he ai contact page yes yeakin nehi hora ha he dakhlo please dakh kar bolo please!!!</h1>
        </div>
    );
};

export default Contact;