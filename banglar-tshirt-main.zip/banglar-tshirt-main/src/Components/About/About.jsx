import React from 'react';

const About = () => {
    return (
        <div>
            <h1>My about page</h1>
        </div>
    );
};

export default About;