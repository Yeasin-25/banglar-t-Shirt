import React from 'react';

const OrderReview = () => {
    return (
        <div>
            <h2>My order review page yes it is my order review page</h2>
        </div>
    );
};

export default OrderReview;